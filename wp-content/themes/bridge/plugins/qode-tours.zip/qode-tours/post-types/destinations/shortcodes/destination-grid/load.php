<?php
require_once 'destination-grid.php';
require_once 'helper-functions.php';